package com.example.moviesrecyclerviewcompany

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.moviesrecyclerviewcompany.databinding.ActivityMainBinding
import com.example.moviesrecyclerviewcompany.interfaces.ApiInterface
import com.example.moviesrecyclerviewcompany.models.Movie
import com.example.moviesrecyclerviewcompany.models.Result
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var moviesList = ArrayList<Result>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        getMovies()

    }

    private fun getMovies() {
        val apiInterface = ApiInterface.getRetrofitObject().create(ApiInterface::class.java)
        val retrofitData = apiInterface.getData("2572f31f3da77472a4d8e2db674cbd71")

        retrofitData.enqueue(object : Callback<Movie?> {
            override fun onResponse(call: Call<Movie?>, response: Response<Movie?>) {
                val responseBody = response.body()
                if (responseBody != null) {
                    moviesList = responseBody.results as ArrayList<Result>
                }
                print(moviesList)
//                if (responseBody != null) {
//                    userList = responseBody
//                }

//                adapter = UsersRecyclerAdapter(userList, this@WsRetrofitUserListActivity)
//                rvRetrofitUserList.adapter = adapter
            }

            override fun onFailure(call: Call<Movie?>, t: Throwable) {
                Toast.makeText(this@MainActivity, "Failed", Toast.LENGTH_SHORT).show()
            }
        })
    }
}